package com.example.unibeapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText user, pass;
    Button Ingresar;
    Button Limpiar;

    ImageButton face;
    ImageButton instagram;
    ImageButton twitter;
    ImageButton you;
    ImageButton link;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        face=findViewById(R.id.imageButtonFace);
        instagram=findViewById(R.id.imageButtonInsta);
        twitter=findViewById(R.id.imageButtonTwitter);
        you=findViewById(R.id.imageButtonYou);
        link=findViewById(R.id.imageButtonLink);

        face.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://www.facebook.com/unibeenlinea");
            }
        });
        instagram.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://www.instagram.com/unibeenlinea/");
            }
        });
        twitter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://twitter.com/unibeenlinea");
            }
        });
        you.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://www.youtube.com/user/unibeenlinea");
            }
        });
        link.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://www.linkedin.com/school/unibe/?originalSubdomain=do");
            }
        });

        user = findViewById(R.id.editTextUser);
        pass = findViewById(R.id.editTextPass);

        Ingresar = findViewById(R.id.buttonIngresar);
        Limpiar = findViewById(R.id.buttonLimpiar);

        Limpiar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                user.setText("");
                pass.setText("");
            }
        });

        Button login = (Button) findViewById(R.id.buttonIngresar);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (user.getText().toString().equals("Anderson") && pass.getText().toString().equals("123")) {
                    Intent intent = new Intent(MainActivity.this, Principal.class);
                    startActivity(intent);
                    //Toast.makeText(MainActivity.this, "Bienvenido", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(MainActivity.this, "Credenciales Incorrectas", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void gotoUrl(String s) {
        Uri uri =Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW,uri));
    }
}